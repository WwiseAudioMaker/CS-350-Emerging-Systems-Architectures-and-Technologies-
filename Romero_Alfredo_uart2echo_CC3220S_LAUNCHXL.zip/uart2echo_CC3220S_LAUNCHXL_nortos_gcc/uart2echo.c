/*
 * uart2echo.c
 * Modified UART echo application to control an LED based on "ON" and "OFF" commands.
 */

#include <stdint.h>
#include <stddef.h>
#include <string.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART2.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    char input;
    unsigned char state = 0; // State variable for command processing
    const char echoPrompt[] = "Enter ON or OFF to control the LED:\r\n";
    UART2_Handle uart;
    UART2_Params uartParams;
    size_t bytesRead;
    size_t bytesWritten = 0;
    uint32_t status = UART2_STATUS_SUCCESS;

    /* Initialize GPIO driver */
    GPIO_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Initialize UART parameters */
    UART2_Params_init(&uartParams);
    uartParams.baudRate = 115200;

    /* Open the UART with the specified parameters */
    uart = UART2_open(CONFIG_UART2_0, &uartParams);
    if (uart == NULL)
    {
        /* UART2_open() failed, enter infinite loop */
        while (1) {}
    }

    /* Turn on LED to indicate successful UART initialization */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Write echo prompt to UART */
    UART2_write(uart, echoPrompt, sizeof(echoPrompt), &bytesWritten);

    /* Turn off the LED after showing initialization */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);

    /* Loop forever reading and processing commands */
    while (1)
    {
        bytesRead = 0;
        /* Read character from UART */
        while (bytesRead == 0)
        {
            status = UART2_read(uart, &input, 1, &bytesRead);
            if (status != UART2_STATUS_SUCCESS)
            {
                /* UART2_read() failed, enter infinite loop */
                while (1) {}
            }
        }

        /* Echo the received character */
        bytesWritten = 0;
        while (bytesWritten == 0)
        {
            status = UART2_write(uart, &input, 1, &bytesWritten);
            if (status != UART2_STATUS_SUCCESS)
            {
                /* UART2_write() failed, enter infinite loop */
                while (1) {}
            }
        }

        /* Process the received character */
        switch (state)
        {
            case 0: // Initial state
                if (input == 'O') state = 1;
                break;
            case 1: // 'O' received
                if (input == 'N') state = 2;
                else if (input == 'F') state = 3;
                else state = 0;
                break;
            case 2: // "ON" command received
                if (input == '\r' || input == '\n')
                {
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                    state = 0;
                }
                else state = 0;
                break;
            case 3: // "OF" received
                if (input == 'F') state = 4;
                else state = 0;
                break;
            case 4: // "OFF" command received
                if (input == '\r' || input == '\n')
                {
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                    state = 0;
                }
                else state = 0;
                break;
            default:
                state = 0;
                break;
        }
    }
}
